import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    paddingVertical: 5,    
    paddingBottom: 10,
  },
});
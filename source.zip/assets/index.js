export const assets = {
    logo: require('./logo.png'),
}